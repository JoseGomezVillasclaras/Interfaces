package ejercicios;
import javax.swing.*;
public class JOptionPane4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		UIManager.put("OptionPane.yesButtonText", "Si");
		UIManager.put("OptionPane.noButtonText", "No");
		
		int codigo=JOptionPane.showConfirmDialog(null, "Tienen un euro para una buena causa",
				"Donacion", JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.INFORMATION_MESSAGE);
		if(codigo==JOptionPane.YES_OPTION) {
			JOptionPane.showConfirmDialog(null, "Gracias");
			
		}else if(codigo==JOptionPane.NO_OPTION) {
			JOptionPane.showConfirmDialog(null, "No pasa nada, Sigue andando");
		}else {
			JOptionPane.showInputDialog(null, " Has cancelado, Dime porque");
		}
		
	}

}
