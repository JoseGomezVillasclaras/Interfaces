package ejercicios;
import javax.swing.JOptionPane;
public class Ej1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nombre="Jose";
		
		JOptionPane.showMessageDialog(null,"Bienvenido "+nombre);
		
		
	}

}
