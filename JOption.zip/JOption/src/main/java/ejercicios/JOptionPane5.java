package ejercicios;
import javax.swing.*;
public class JOptionPane5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UIManager.put("OptionPane.yesButtonText", "Si");
		UIManager.put("OptionPane.noButtonText", "No");
		
		int codigo=JOptionPane.showConfirmDialog(null, "¿Has tenido vacaciones este puente?",
				"Encuesta", JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.INFORMATION_MESSAGE);
		if(codigo==JOptionPane.YES_OPTION) {
		
			JOptionPane.showMessageDialog(null, "Perfecto, preparate que ahora si que empieza el curso");
		}else if(codigo==JOptionPane.NO_OPTION) {
			String respuesta=JOptionPane.showInputDialog(null, "No pasa nada, Mas te vale dormir bien porque te van a faltar horas, ¿Qué metodo vas a usar?");
			if(respuesta!=null) {
				JOptionPane.showMessageDialog(null, "Perfecto espero que "+respuesta+" te sea de ayuda");
				
			}
		}else {
			JOptionPane.showInputDialog(null, " Has cancelado, ¿Eres tonto o no sabes español?");
		}
	}

}
